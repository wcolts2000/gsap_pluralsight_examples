$(document).ready(function(){
    init();
});


function init(){

}